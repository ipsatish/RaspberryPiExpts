#!/usr/bin/python

import RPi.GPIO as GPIO
import time, sys, getopt

def main():
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
	#BCM GPIOs  4, 17, 27, 22,  5,  6, 13, 19 used to control Relays
	#BCM GPIOs 26, 21, 20, 16, 12, 25, 24, 23 used for manual control of relays (Switches)
	switch_pin = 26
	relay_pin = 4
        GPIO.setup(switch_pin,GPIO.IN)
	GPIO.setup(relay_pin,GPIO.OUT)
	while True:
		sw_state = GPIO.input(switch_pin)
		if (sw_state == 0):
			print "Switch pressed!"
			print "Checking current relay state..."
			cur_val = GPIO.input(relay_pin)
			if cur_val == 0:
				GPIO.output(relay_pin,1)
			if cur_val == 1:
				GPIO.output(relay_pin,0)	
			time.sleep(1)


if __name__ == "__main__":
        sys.exit(main())

