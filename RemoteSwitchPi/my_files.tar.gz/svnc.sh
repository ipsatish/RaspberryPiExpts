#!/bin/sh
vncserver :1 -geometry 1024x768 -depth 24 -dpi 96
